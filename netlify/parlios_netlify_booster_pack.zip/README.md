# Parlios — Netlify Booster Pack
Generated: 2025-09-28T03:13:05

This pack gives you a professional baseline for a high‑quality Netlify deployment.

## What's inside
- `netlify.toml` — redirects, headers, edge rules, build settings
- `_headers` — strict security headers as a fallback
- `_redirects` — clean redirects (SPA fallback + www → apex)
- `robots.txt` — allows indexing + sitemap
- `sitemap.xml` — template (update URLs if needed)
- `security.txt` — contact channel for security
- `manifest.webmanifest` — PWA manifest
- `sw.js` — starter service worker (cache‑first for static)
- `seo/head-snippets.html` — meta, OG, Twitter cards, theme color
- `seo/schema-organization.jsonld` — JSON‑LD Organization schema
- `forms/lead-form.html` — accessible, Netlify Forms‑ready lead form
- `lighthouse-ci.json` — Lighthouse CI thresholds for PRs

## How to use
1. Drop these files at your site root (or merge per folder).
2. Adjust domain and brand fields in `manifest.webmanifest`, `sitemap.xml`, and `seo/*`.
3. Commit → Netlify will auto‑pick config.
4. Optional: enable Netlify Analytics, Forms, and Edge Functions.
